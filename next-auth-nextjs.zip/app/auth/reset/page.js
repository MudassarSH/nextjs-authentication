import { ResetForm } from '@/components/auth/reset-form'
import React from 'react'

const ResetPage = () => {
  return (
    <ResetForm/>
  )
}

export default ResetPage
import { PasswordForm } from '@/components/auth/new-password'
import React from 'react'

const NewPassword = () => {
  return (
    <PasswordForm/>
  )
}

export default NewPassword
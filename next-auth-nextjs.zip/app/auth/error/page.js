import { ErrorCard } from '@/components/auth/error-card'
import React from 'react'

const ErrorPage = () => {
  return (
    <ErrorCard/>
  )
}

export default ErrorPage
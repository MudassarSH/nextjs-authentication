import { NewVerficationForm } from '@/components/auth/verfication-form'
import React from 'react'

const NewVerfication = () => {
  return (
    <NewVerficationForm/>
  )
}

export default NewVerfication